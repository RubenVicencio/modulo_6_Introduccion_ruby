# Patrón 4
# ruby patron4.rb 18
# 123123123123123123

n = ARGV[0].to_i

print "\n"
n = ARGV[0].to_i

print "\n"
n.times do |i|
    if i % 3 == 0 
        print "1"
    elsif
        i % 3 == 1
        print "2"
    elsif
        i % 3 == 2
        print "3"    
    end
    
end
print "\n"*2