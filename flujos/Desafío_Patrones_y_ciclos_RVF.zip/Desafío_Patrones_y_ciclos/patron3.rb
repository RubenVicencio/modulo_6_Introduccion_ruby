# Patrón 3
# ruby patron3.rb 15
# 121212121212121

n = ARGV[0].to_i

print "\n"
n = ARGV[0].to_i

print "\n"
n.times do |i|
    if i % 2 == 0 
        print "1"
    else
        print "2"
    end
    
end
print "\n"*2


print "\n"*2