i = 0
suma = 0
while(i < 10)
    suma += i
    i += 1
end
puts suma